var express = require('express'),
    exphbs = require('express-handlebars'),
    logger = require('morgan'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    methodOverride = require('method-override'),
    session = require('express-session');

//AWS packages
var AWS = require('aws-sdk');
var DOC = require('dynamodb-doc');
AWS.config.update({region: 'us-west-2'});
var docClient = new DOC.DynamoDB();

//'Boolean' variable for checking if the account exists
var accountExists = 0;

//Global Name for storing the table names for dashboard generation
var globalName = "hello";
var dashBoard_data;

var app = express();

//Socket.io packages
var server = require('http').createServer(app);
var io = require('socket.io')(server);

//configure Express
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(methodOverride('X-HTTP-Method-Override'));
app.use(session({secret: 'supernova'}));

server.listen(4700);
console.log("listening on 4700!");

// Routes
app.get('/', function(req, res, next){
	res.sendFile(__dirname + '/index.html')
})

app.get('/login', function(req, res, next){
	res.sendFile(__dirname + '/login.html')
})

app.get('/signup', function(req, res){
	res.sendFile(__dirname + '/register.html')
})

app.get('/dash', function(req, res){
	authenticate(globalName, globalTag, globalPass, function(queryRes){
		jsonString = JSON.parse(JSON.stringify(queryRes))
		if(jsonString["Count"] == 0){
			console.log("No Account!")
			res.redirect('/login')
		} else {
			getData(globalName, function(db_company){
				dashBoard_data = JSON.parse(JSON.stringify(db_company));
				var itemArray = dashBoard_data["Items"];
				var handleArray = [];
				var tweetArray = [];
				for(var i = 0; i < itemArray.length; i++){
					var obj = itemArray[i];
					console.log(obj.TwitterHandleTweet);
					var handle = obj.TwitterHandleTweet.substring(0, obj.TwitterHandleTweet.indexOf("tweeted"));
					var tweet = obj.TwitterHandleTweet.substring(obj.TwitterHandleTweet.indexOf(":") + 1);
					handleArray.push(handle);
					tweetArray.push(tweet);
				}
				res.set('Content-Type', 'text/html')
				res.send("<body> " + "<link href='https://bootswatch.com/flatly/bootstrap.min.css' rel='stylesheet'>" + "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>" + "</body>" + "<div class='panel panel-default'> <div class='panel-heading text-center'><h1>Top Tweeters</h1></div> <div class='panel-body'> <p>The top ten will recieve promotional codes/free swag</p></div>\
					<ul class='list-group'><li class='list-group-item'>" + handleArray [0] + "</li><li class='list-group-item'>" + handleArray [1] + "</li><li class='list-group-item'>" + handleArray [2] + "</li><li class='list-group-item'>" + handleArray [3] + "</li><li class='list-group-item'>" + handleArray [4] + "</li><li class='list-group-item'>" + handleArray [5] + "</li><li class='list-group-item'>" + handleArray [6] + "</li><li class='list-group-item'>" + handleArray [7] + "</li><li class='list-group-item'>" + handleArray [8] + "</li><li class='list-group-item'>" + handleArray [9] + "</li><div class='page-header text-center'>" + "<div class='jumbotron'>" + "<h1>Top Tweets</h1>" + "<p>" + tweetArray[0] + "<br><br>" + tweetArray[1] + "<br><br>" + tweetArray[2] + "<br><br>" + tweetArray[3] + "<br><br>" + tweetArray[4] + "<br><br>" + tweetArray[5] + "<br><br>" + tweetArray[6] + "<br><br>" + tweetArray[7] + "<br><br>" + tweetArray[8] + "<br><br>" + tweetArray[9] + "</p>" + "</div> <a href='/logout' class='btn btn-default btn-sm'>Logout</a> " + "</div>\
					")
			})
		}
	})
})

app.get('/logout', function(req, res){
	res.redirect('/')
})

//post requests
app.post('/signup', function(req, res){
	console.log(req.body.name);
	console.log(req.body.tag);
	console.log(req.body.pass);
	
	//things to put into DynamoDB
	companyName = req.body.name;
	hashTag = req.body.tag;
	password = req.body.pass;

	//do the actual posting
	register(companyName, hashTag, password);
	res.redirect('/');
})

app.post('/login', function(req, res){
	console.log(req.body.name);
	console.log(req.body.tag);
	console.log(req.body.pass);

	//Things to get from DynamoDB
	globalName = req.body.name;
	var companyName = req.body.name;

	globalTag = req.body.tag;
	var hashTag = req.body.tag;
	
	globalPass = req.body.pass;
	var password = req.body.pass;

	res.redirect('/dash');

	
})

function register(companyName, hashtag, password){
	//Specify Paramters and post
	var params = {};
	params.TableName = "angelhacks2";
	params.Item = {companyName: companyName, hashtag: hashTag, password: password, tweets:[]};
	docClient.putItem(params, function(err, data){
		if(err){
			console.log(err, err.stack)
		} else {
			console.log("Successfully updated!");
		}
	})
}

function getData(companyName, callback){
	var params = {TableName: companyName};
	docClient.scan(params, function(err, data){
		if(err){
			console.log(err, err.stack)
		} else{
			console.log(data);
			callback(data);
			putData(data);
		}
	})
}

function putData(data){
	dashBoard_data = data;
}

function authenticate(companyName, hashtag, password, callback){
	//User Authentication (check if it's in the query response)
	var queryParams = {};
	queryParams.TableName = "angelhacks2";
	queryParams.KeyConditions = [docClient.Condition("companyName", "EQ", companyName),
								docClient.Condition("hashtag", "EQ", hashtag)];
	queryParams.QueryFilter = docClient.Condition("password", "EQ", password);
	docClient.query(queryParams, function(err, result){
		if(err){
			console.log(err, err.stack)
			console.log("Error");
		} else {
			callback(result);
		}
	})

}

function check(companyName, hashtag, callback){
	//under construction
}
